package com.geninvo.service;

/*
 * ShopService is service class to communicate to database.
 */

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.geninvo.model.Shops;
import com.geninvo.repository.ShopRepositoryInterface;

@Service
public class ShopService {

	@Autowired
	private ShopRepositoryInterface shopRepositoryInterface;	
	public ShopService(){}
	
	/*
	 *  handling request which is coming for fetching records from database for specific name.
	 */
	public List <Shops> getShops(String name){
		
		return shopRepositoryInterface.findByshopName(name);
	}
	/*
	 *  handling request which is coming for fetching all records from database.
	 */
	public List <Shops> getAllShops(){
		
		return (ArrayList<Shops>) shopRepositoryInterface.findAll();
	}
	/*
	 *  handling request which is coming for creating new record in database.
	 */
	public Shops save(Shops shop) {
		
		return shopRepositoryInterface.save(shop); 
	}
}
