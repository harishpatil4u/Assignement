package com.geninvo.controller;

/*
 * ShopController is to controller class to handle incoming requests from clients.
 */

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.geninvo.model.Shops;
import com.geninvo.service.ShopService;

@RestController
@CrossOrigin
@RequestMapping("/shops")
public class ShopController {

	@Autowired
	private ShopService SS;
	
	/*
	 *  handling request which is coming for fetching records from database for specific name.
	 */
	@CrossOrigin
	@GetMapping("/{name}")
	public List <Shops> getShop(@PathVariable("name") String name){
		return SS.getShops(name);
	}
	
	/*
	 *  handling request which is coming for creating new record in database.
	 */
	@PostMapping("/create")
	public Shops createShop(@RequestBody Shops shop){
		return SS.save(shop);
	}
	
	/*
	 *  handling request which is coming for fetching all records from database.
	 */
	@CrossOrigin
	@GetMapping("/all")
	public  List <Shops> getAllShops(){
		return SS.getAllShops();
	}	
}
