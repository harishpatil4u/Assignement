package com.geninvo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "shops")
public class Shops {
	
	public Shops() {}
	public Shops(String shopName, String shopCategory, String shopAddress, String shopLatitude, String shopLongitude, String shopOwnerName) {
		
		this.shopName = shopName;
		this.shopCategory = shopCategory;
		this.shopAddress = shopAddress;
		this.shopLatitude = shopLatitude;
		this.shopLongitude = shopLongitude;
		this.shopOwnerName = shopOwnerName;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "shop_id")
	private int shopId;

	@Column(name = "shop_name")
	private String shopName;

	@Column(name = "shop_category")
	private String shopCategory;

	@Column(name = "shop_address")
	private String shopAddress;

	@Column(name = "shop_latitude")
	private String shopLatitude;

	@Column(name = "shop_longitude")
	private String shopLongitude;

	@Column(name = "shop_owner_name")
	private String shopOwnerName;

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopCategory() {
		return shopCategory;
	}

	public void setShopCategory(String shopCategory) {
		this.shopCategory = shopCategory;
	}

	public String getShopAddress() {
		return shopAddress;
	}

	public void setShopAddress(String shopAddress) {
		this.shopAddress = shopAddress;
	}

	public String getShopLatitude() {
		return shopLatitude;
	}

	public void setShopLatitude(String shopLatitude) {
		this.shopLatitude = shopLatitude;
	}

	public String getShopLongitude() {
		return shopLongitude;
	}

	public void setShopLongitude(String shopLongitude) {
		this.shopLongitude = shopLongitude;
	}

	public String getShopOwnerName() {
		return shopOwnerName;
	}

	public void setShopOwnerName(String shopOwnerName) {
		this.shopOwnerName = shopOwnerName;
	}

}
