package com.geninvo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.geninvo.model.Shops;


/*
 * ShopRepositoryInterface is interface of CrudRepository to communicate to database.
 */
public interface ShopRepositoryInterface extends CrudRepository<Shops, Integer>{

	List <Shops> findByshopName(String shopName);
}
